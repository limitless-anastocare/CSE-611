package com.limitless.dao;

import java.util.Optional;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

import com.limitless.model.Signup;

public class SignupRepositoryImp implements SignupRepository {
	 private JdbcTemplate jdbcTemplate;
	    public SignupRepositoryImp(DataSource dataSource) {
	    	this.jdbcTemplate =new JdbcTemplate(dataSource);
	    }
	    
	public SignupRepositoryImp() {
			super();
			// TODO Auto-generated constructor stub
		}

	@Override
	public int save(Signup s) {
		String sql="INSERT INTO Patient_SignUp(first_name,last_name,dob,mobile,email,password) VALUES (?,?,?,?,?,?)";
		return jdbcTemplate.update(sql,s.getFirst_name(),s.getLast_name(),s.getDob(),s.getMobile(),s.getEmail(),s.getPassword());
	}
//	public int login(String email,String pass)
//	{
//		String sql="Select email,password from signup where email=email and password=pass";
//	}

	@Override
	public Object save(Object entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable saveAll(Iterable entities) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Optional findById(Object id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean existsById(Object id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Iterable findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Iterable findAllById(Iterable ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void deleteById(Object id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(Object entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAllById(Iterable ids) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll(Iterable entities) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub
		
	}
}
