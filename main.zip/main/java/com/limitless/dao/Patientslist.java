package com.limitless.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.limitless.model.Signup;
import com.limitless.model.patient;

//@Service
public class Patientslist implements Patient_adminViewRepo{


	    
	    private patientrepo repository;

	    public List<patient> findAll() {

	        var patients = (List<patient>) repository.findAll();

	        return patients;
	    }
	}


