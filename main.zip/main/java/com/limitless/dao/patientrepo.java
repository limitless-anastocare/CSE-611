package com.limitless.dao;

import java.util.List;

import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.limitless.model.Signup;
import com.limitless.model.patient;

@Component
public interface patientrepo extends JpaRepository<patient,String>{
	
	List<patient> getUserByUname(String first_name);

	List<patient> findByUnameOrderByUidAsc(String first_name);

	@Query("from User where first_name= :first_name")
	List<User> find(@Param("first_name") String first_name);
}

