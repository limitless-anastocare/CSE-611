package com.limitless.model;
import lombok.*;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.*;



import org.springframework.data.annotation.Id;
import org.springframework.format.annotation.DateTimeFormat;


//@Data
@Entity
@Table(name = "Patient_SignUp")
public class Signup  {
    
    public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirst_name() {
		return first_name;
	}
	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}
	public String getLast_name() {
		return last_name;
	}
	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public int getMobile() {
		return mobile;
	}
	public void setMobile(int mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Id
    private int id;
	@NotBlank(message="First Name is required")
//	@Column(name = "first_name")
    private String first_name;
   
    @NotBlank(message="Last Name is required")
//    @Column(name = "last_name")
    private String last_name;
    @NotNull
    @NotBlank(message="Give your date of birth")
    @DateTimeFormat(pattern = "yyyy-mm-dd")
//    @Column(name = "dob")
    private String dob;
    
    @Digits(integer=10, fraction=0, message="Invalid mobile number")
//    @Column(name = "mobile")
    private int mobile;
    @Email(message = "invalid email_id") 
//    @Column(name = "email")
    private String email;
    @NotNull
    @Size(min=5, message="password must be at least 5 characters long")
//    @Column(name = "password")
    private String password;
    
}
