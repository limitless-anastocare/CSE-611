package com.limitless.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;

import com.limitless.model.Signup;
@Controller
public class HomeController {
 @GetMapping("/index")
 public String home() {
 return "index";
  }
@GetMapping("/signup")
 public String signup( Model model) {
	
	Signup signup=new Signup();
	model.addAttribute("signup",signup);
 return "signup";
  }
 
@GetMapping("/login")
public String login() {
return "login";
 }

@GetMapping("/contact")
public String contact() {
return "contact";
 }


}

