package com.limitless.controllers;




import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


import com.limitless.configure.DatasourceConfig;
import com.limitless.dao.SignupRepository;
import com.limitless.dao.SignupRepositoryImp;
//import com.limitless.dao.SignupRepositoryImp;
import com.limitless.model.Signup;


@Controller
public class SignupController {
	 
	   SignupRepository dao;
//	   private DriverManagerDataSource  dataSource;
//	   Database_config df;
//	   dao=new SignupRepositoryImp(dataSource);
//		void setup()
//		{
//			dataSource=new DriverManagerDataSource();
//			dataSource.setUrl("jdbc:postgresql://localhost:5432/limitless");
//			dataSource.setUsername("postgres");
//			dataSource.setPassword("qamar@123");
//			dao=new SignupRepositoryImp(dataSource);
//		}

	@PostMapping("/save")
//	@ResponseBody
	public String signup( @Valid Signup signup, BindingResult bindingResult) {
		if (bindingResult.hasErrors()) {
			return "signup";
		}
//		dataSource=new DriverManagerDataSource();
		DatasourceConfig ds=new DatasourceConfig();
//		Model model.addAttribute("signup", signup);
//		df=new Database_config();
//		df.setup(dataSource);
		dao=new SignupRepositoryImp(ds.datasource());
		dao.save(signup);
		    
		System.out.println(signup.toString());
		    
		
//		;
       return "login";
	}

}
