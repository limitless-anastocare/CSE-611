package com.limitless.controllers;
import java.util.List;

import javax.sql.DataSource;

import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;

import com.limitless.configure.DatasourceConfig;
import com.limitless.dao.AdminviewPatRepoImp;
import com.limitless.dao.Patient_adminViewRepo;
import com.limitless.dao.Patientslist;
import com.limitless.model.Signup;
import com.limitless.model.patient;
@Controller
public class AdminController {
 private JdbcTemplate jdbcTemplate;



@GetMapping("/")
 public String adminLogin() {
 return "adminlogin";
  }
 
 @GetMapping("/AdminLogin")
 public String adminDashboard() {
 return "adminDashboard";
  }

 
 
 @GetMapping("/PatientDetails")
 
 public String viewpat() {
	
	// System.out.println("ccccccc" + p.getList());
	 DatasourceConfig d = new  DatasourceConfig();
	 DataSource da = d.datasource();
	 setDataSource(da);
	 System.out.println(getList());
	 List l = getList();
	 return "patientDetails";
	  }

 public void setDataSource(DataSource dataSource) {
     this.jdbcTemplate = new JdbcTemplate(dataSource);
 }
 public List getList() {
     return this.jdbcTemplate.queryForList("select first_name,last_name,email from patient_signup");
 }
 


}

