package com.limitless.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;

import com.limitless.model.Signup;
@Controller
public class LoginController {
 @GetMapping("/Login to Limitless")
 public String LogintoLimitless() {
 return "userdash";
  }

}

